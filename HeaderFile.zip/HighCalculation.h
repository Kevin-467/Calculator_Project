//High Accuracy Calculation (Only support Positive Interger)
#pragma once
typedef unsigned long long ull;
class HighCalculation
{
public:
    HighCalculation(){}
    ~HighCalculation(){}
    HighCalculation operator +(HighCalculation h1);
    HighCalculation operator -(HighCalculation h1);
    HighCalculation operator *(ull h1);
    HighCalculation operator *(HighCalculation h1);
    HighCalculation operator /(ull h1);
    HighCalculation operator /(HighCalculation h1);
    HighCalculation operator %(ull h1);
    HighCalculation operator %(HighCalculation h1);
    HighCalculation operator !();
    bool operator >(HighCalculation h1);
    bool operator ==(HighCalculation h1);
    friend bool operator <(HighCalculation h1,HighCalculation h2);
    friend bool operator >=(HighCalculation h1, HighCalculation h2);
    friend  bool operator <=(HighCalculation h1, HighCalculation h2);
};

