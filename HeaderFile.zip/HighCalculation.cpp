#include "HighCalculation.h"
#include <algorithm>
#include <vector>
#include <iterator>
#include <string>
#include <cmath>

HighCalculation HighCalculation::operator+(HighCalculation h1)
{
    return HighCalculation();
}

HighCalculation HighCalculation::operator-(HighCalculation h1)
{
    return HighCalculation();
}

HighCalculation HighCalculation::operator*(ull h1)
{
    return HighCalculation();
}

HighCalculation HighCalculation::operator*(HighCalculation h1)
{
    return HighCalculation();
}

HighCalculation HighCalculation::operator/(ull h1)
{
    return HighCalculation();
}

HighCalculation HighCalculation::operator/(HighCalculation h1)
{
    return HighCalculation();
}

HighCalculation HighCalculation::operator%(ull h1)
{
    return HighCalculation();
}

HighCalculation HighCalculation::operator%(HighCalculation h1)
{
    return HighCalculation();
}

HighCalculation HighCalculation::operator!()
{
    return HighCalculation();
}

bool HighCalculation::operator>(HighCalculation h1)
{
    return true;
}

bool HighCalculation::operator==(HighCalculation h1)
{
    return true;
}

bool operator<(HighCalculation h1, HighCalculation h2)
{
    return false;
}

bool operator>=(HighCalculation h1, HighCalculation h2)
{
    return false;
}

bool operator<=(HighCalculation h1, HighCalculation h2)
{
    return false;
}
